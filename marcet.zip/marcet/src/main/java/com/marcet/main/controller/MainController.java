package com.marcet.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.marcet.mct.service.MctService;
import com.webjjang.util.PageObject;

@Controller
@RequestMapping("/main")
public class MainController {

	// 자동 DI 적용
	@Autowired
	
	private MctService mctService;
	
	@GetMapping("/main.do")
	public String main(Model model) throws Exception{
		PageObject pageObject = new PageObject(1, 4);
		model.addAttribute("mctList", mctService.list(pageObject));	
		return "main/main";
	}
}
