package com.marcet.member.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.marcet.member.mapper.MemberMapper;
import com.marcet.member.vo.LoginVO;
import com.marcet.member.vo.MemberVO;
import com.webjjang.util.PageObject;

@Service
public class MemberService {

	// 자동 DI
	@Inject
	private MemberMapper mapper;
	
	// 회원 리스트
	public List<MemberVO> list(PageObject pageObject) throws Exception{
		// 전체 데이터의 갯수를 구해서 pageObject에 넣는다.
		pageObject.setTotalRow(mapper.getTotalRow(pageObject));
		return mapper.list(pageObject);
	}
	
	// 회원 보기
	public MemberVO view(String id) throws Exception{
		return mapper.view(id);
	}
	
	
	// 회원가입
	public int write(MemberVO vo) throws Exception{
		return mapper.write(vo);
	}
	
	// 회원정보 수정
	public int update(MemberVO vo) throws Exception{
		return mapper.update(vo);
	}
	
	// 회원 탈퇴
	public int delete(MemberVO vo) throws Exception{
		return mapper.delete(vo);
	}
	
	// 로그인
	public LoginVO login(LoginVO invo) throws Exception{
		return mapper.login(invo);
		
	}	
	// 아이디 중복 체크 -> 아이디를 가져오자
		public String idCheck(String id) throws Exception{
			
		return mapper.idCheck(id);
	}
		
	// 상태 변경
		public int changeStatus(MemberVO vo) throws Exception{
			
			return mapper.changeStatus(vo);
		}
	// 상태 변경
		public int changeGradeNo(MemberVO vo) throws Exception{
			
			return mapper.changeGradeNo(vo);
		}

		
}
